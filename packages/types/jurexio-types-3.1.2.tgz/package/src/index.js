/**
 * @nyayavigya/types v3.1.2
 * Nyayavigya Platform 312 — Shared TypeScript Types
 *
 * Exports all types used by:
 *  - @nyayavigya/client-sdk
 *  - NYV Gateway API
 *  - All 5 Nyayasiddhi platforms
 *  - ROMA L5 agents
 */
export {};
//# sourceMappingURL=index.js.map