# @nyayavigya/client-sdk

Official TypeScript SDK for Nyayavigya Platform 3.1.2 — India's Sovereign Legal AI OS.

## Installation

```bash
npm install @nyayavigya/client-sdk
```

## Quick Start

```typescript
import { NyvClient } from '@nyayavigya/client-sdk';

const nyv = new NyvClient({
  apiKey: 'nyv_live_sk_your_api_key',
  baseUrl: 'https://YOUR_REPLIT_URL',
});

// Simple legal query
const answer = await nyv.ask('What are the grounds for divorce under Hindu Marriage Act 1955?');
console.log(answer);

// Pattern execution (22 patterns: P01-P22)
const result = await nyv.patterns.cot({
  task: 'Analyse enforceability of non-compete clauses in India',
  jurisdiction: 'IN',
});

// Stream with AG-UI events
await nyv.stream.streamPattern('nyayarag', {
  task: 'Explain Section 302 of BNS 2023',
  jurisdiction: 'IN',
}, {
  onThinking: (step) => console.log('Thinking:', step),
  onTextDelta: (delta) => process.stdout.write(delta),
  onComplete: (result) => console.log('Done:', result.traceId),
});
```

## API Classes

| Class | Purpose |
|-------|---------|
| `nyv.patterns` | Execute 22 agentic patterns (ReAct, CoT, ToT, NyayaRAG, GraphRAG, etc.) |
| `nyv.documents` | Upload, search, classify legal documents |
| `nyv.agents` | Access 149 ROMA L5 legal agents |
| `nyv.skills` | Browse and execute agent skills |
| `nyv.twins` | Create and simulate digital twins |
| `nyv.knowledge` | GraphRAG knowledge base operations |
| `nyv.voice` | Voice synthesis and transcription |
| `nyv.stream` | AG-UI SSE streaming |

## Configuration

```typescript
const nyv = new NyvClient({
  apiKey: 'nyv_live_sk_...',           // Required: SDK API key
  baseUrl: 'https://api.nyayavigya.in', // Required: Gateway URL
  defaultPlatform: 'nys-professional',  // Optional: Platform context
  defaultJurisdiction: 'IN',           // Optional: Default jurisdiction
  timeout: 30000,                      // Optional: Request timeout (ms)
});
```

## Supported Jurisdictions

IN (India), UK (United Kingdom), US (United States), EU (European Union), GCC (Gulf), SG (Singapore)

## Version

3.1.2 (Frozen until September 2026)

## License

PROPRIETARY — Nyayavigya Technology Pvt Ltd
