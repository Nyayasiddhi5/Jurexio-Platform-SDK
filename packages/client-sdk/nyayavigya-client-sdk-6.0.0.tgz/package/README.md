# `@nyayavigya/client-sdk`

> Official TypeScript SDK for the **Nyayavigya Legal AI Platform** — v6 GA.

Powers all 5 Nyayasiddhi platforms (NSP web/mobile, Nyayamitra, Institutional,
Academy, Ministry) and external developer integrations.

| | |
|---|---|
| Package | `@nyayavigya/client-sdk` |
| Version | **6.0.0** (GA — 2026-04-25) |
| Min Node | 22.x |
| Modules | ESM + CJS, full `.d.ts`, tree-shakeable |
| Companion | `@nyayavigya/types`, `@nyayavigya/react-hooks`, `@nyayavigya/client-sdk-react-native`, `@nyayavigya/nyayamitra-sdk` |

---

## Install

```bash
npm install @nyayavigya/client-sdk @nyayavigya/types
```

## 60-second quickstart

```ts
import { NyvClient } from '@nyayavigya/client-sdk';

const nyv = new NyvClient({
  apiKey:  process.env.NYV_API_KEY!,        // nyv_live_sk_...
  baseUrl: 'https://app.nyayavigya.in',
});

// 1) Ask a legal question (P11 NyayaRAG)
const ans = await nyv.ask(
  'Explain BNS 2023 Section 103 (murder) with relevant case law',
);
console.log(ans.content);

// 2) Stream a Chain-of-Thought run with AG-UI events
await nyv.stream.streamPattern('cot', { task: ans.followUp ?? '' }, {
  onThinking:  (step, i, n) => console.log(`step ${i}/${n}: ${step}`),
  onTextDelta: (delta) => process.stdout.write(delta),
  onComplete:  (final)  => console.log('\n— done', final.traceId),
});

// 3) Upload a document for RAG indexing
const { docId } = await nyv.documents.uploadFormData(file, { fileName: 'contract.pdf' });
const doc = await nyv.documents.waitForCompletion(docId);
```

## API surface

`NyvClient` exposes 14 API classes covering the full v6 gateway:

| Property | Class | Purpose |
|---|---|---|
| `nyv.patterns` | `PatternsApi` | All 22 agentic patterns (P01–P22) |
| `nyv.documents` | `DocumentsApi` | Upload, OCR, indexing, search, RAG |
| `nyv.agents` | `AgentsApi` | Discovery + execution of 1,043 agents |
| `nyv.skills` | `SkillsApi` | 100+ legal skills (drafting, review…) |
| `nyv.twins` | `TwinApi` | Digital twin creation + simulation |
| `nyv.knowledge` | `KnowledgeApi` | Knowledge graph + corpus search |
| `nyv.voice` | `VoiceApi` | Sarvam voice synthesis + transcription |
| `nyv.intelligence` | `IntelligenceApi` | Citation check, legal diff, templates |
| `nyv.testing` | `TestingApi` | Eval harness + LLM-as-Judge |
| `nyv.compliance` | `ComplianceApi` | DPDP/GDPR audit + redaction |
| `nyv.nyayatools` | `NyayaToolsApi` | India tax + GST + government APIs |
| `nyv.memory` | `MemoryApi` | Mem0 long-term memory persistence |
| `nyv.cache` | `CacheApi` | Semantic cache invalidation + stats |
| `nyv.credits` | `CreditsApi` | Org credit balance + usage |
| `nyv.stream` | `NyvStreamReader` | AG-UI SSE streaming for any pattern |

## Streaming (AG-UI)

```ts
await nyv.stream.streamPattern('react', { task: '...' }, {
  onAgentSelected: (agent) => console.log('routed to', agent),
  onThinking:      (step)  => console.log('… ', step),
  onToolCall:      (tool, input)  => console.log(`→ ${tool}`, input),
  onToolResult:    (tool, result) => console.log(`← ${tool}`, result),
  onTextDelta:     (delta) => process.stdout.write(delta),
  onComplete:      (final) => console.log('done', final.traceId),
});
```

The reader handles SSE reconnect, AG-UI v1 + legacy event shapes, and resolves
on `run_finished`. See [`NyvStreamReader`](./src/NyvStreamReader.ts) for full
options.

## Error handling

Every error is a `NyvError` with a stable `code`:

```ts
import { NyvClient, NyvError } from '@nyayavigya/client-sdk';

try { await nyv.ask('...'); }
catch (e) {
  if (e instanceof NyvError) {
    console.error(e.code, e.status, e.traceId, e.message);
    if (e.code === 'RATE_LIMITED') await sleep(60_000);
    if (e.code === 'AUTH_INVALID') refreshKey();
  }
}
```

## Webhooks

Configure a webhook URL + secret in the developer console (`/console/apps`).
On orchestration completion you'll receive a `POST` to your URL with:

```
X-NYV-Event: orchestration.completed
X-NYV-Timestamp: 2026-04-25T10:15:42.123Z
X-NYV-Signature: sha256=<hex hmac of `${ts}.${body}`>
X-NYV-Correlation-Id: <correlationId>
```

Verify with:

```ts
import crypto from 'node:crypto';

function verify(rawBody: string, sig: string, ts: string, secret: string) {
  const expected = 'sha256=' +
    crypto.createHmac('sha256', secret).update(`${ts}.${rawBody}`).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
}
```

## Documentation

- [v6 API Reference](../../docs/v3.1.2/completed_docs/NYV-SDK-v6-API-REFERENCE.md)
- [v6 Integration Guide](../../docs/v3.1.2/completed_docs/NYV-SDK-v6-INTEGRATION-GUIDE.md)
- [v5 → v6 Deprecation Policy](../../docs/v3.1.2/superseded/NYV-SDK-v5-DEPRECATION-POLICY.md)
- [Mobile Integration Guide](../../docs/v3.1.2/completed_docs/NYV-MOBILE-INTEGRATION-GUIDE.md)
- [`CONTRIBUTING.md`](./CONTRIBUTING.md) · [`CHANGELOG.md`](./CHANGELOG.md) · [`SEMVER.md`](./SEMVER.md)

## License

Proprietary — © Nyayavigya Technology Pvt Ltd.
