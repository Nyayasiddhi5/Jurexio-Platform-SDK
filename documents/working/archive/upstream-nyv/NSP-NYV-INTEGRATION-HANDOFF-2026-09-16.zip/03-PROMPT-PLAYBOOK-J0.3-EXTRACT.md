# NSP Prompt Playbook Extract — §J.0.1–§J.0.3

> **Standalone extract** from [`02-PARTNER-AI-INTEGRATION-FULL-2026-09-02.md`](./02-PARTNER-AI-INTEGRATION-FULL-2026-09-02.md) §J.0.1–§J.0.3 (source lines 999–1050).  
> For endpoint matrices, curl examples, stream semantics, and §J.1–§J.9 detail, read the full partner doc or [`01-NSP-MIGRATION-GO-2026-09-08.md`](./01-NSP-MIGRATION-GO-2026-09-08.md).

**Live deploy (nysdev):** `2026-09-15T0837Z-aws-ssm-04625127` · API `https://api.nyayasiddhi.online`

---

#### J.0.1 NSP migration checklist — **REQUIRED** (GO 2026-09-08)

Full copy-paste examples: [`01-NSP-MIGRATION-GO-2026-09-08.md`](./01-NSP-MIGRATION-GO-2026-09-08.md).

| # | Change | Status |
|---|--------|--------|
| 1 | Replace sync bare `legal-draft` with `legal-draft-fast` | **REQUIRED** |
| 2 | Add `parameters.documentType` (snake_case registry key) | **REQUIRED** |
| 3 | Add `options.draftLength: "medium"` (default) | **REQUIRED** |
| 4 | Send `X-NYV-User-Id` or body `userId` (numeric) for memory | **REQUIRED** |
| 5 | Use `/api/nv/orchestrate/stream` for progressive editor UX | **REQUIRED** for editor |
| 6 | Counsel full pleadings → async worker + bare `legal-draft` poll | **REQUIRED** for Queen depth |
| 7 | Verify memory probe passes on EC2 post-deploy | **REQUIRED** |
| 8 | Stream typed drafts via `/api/nv/orchestrate/stream`; gated → **replace** body | **REQUIRED** (NV-DRAFT-STREAM-DUP-001) |
| 9 | Expect ~23s bail medium at SLA cap — use stream for editor UX | **REQUIRED** (NV-DRAFT-FAST-SLA-001) |
| 10 | Live probes: **SKIP** when keys absent — never fake PASS | **REQUIRED** (NSP ops contract) |

Full detail: [`01-NSP-MIGRATION-GO-2026-09-08.md`](./01-NSP-MIGRATION-GO-2026-09-08.md) §J.A–§J.D.

#### J.0.2 Stream + SLA quick reference (2026-09-09)

**Stream (NV-DRAFT-STREAM-DUP-001):** Use `POST /api/nv/orchestrate/stream` with `legal-draft-fast` + `parameters.documentType`. Gated SSE deltas (`gated: true`) → **replace** entire body, not append. Deploy `2026-09-09T1042Z-aws-ssm-02b7885f`.

**SLA (NV-DRAFT-FAST-SLA-001):** `NYV_DRAFT_FAST_SLA=1` (default ON on nysdev) caps medium at **2560** tokens, skips statute QA/Haiku polish — bail medium **~65s → ~23s**; warm **~67ms**. Set `NYV_DRAFT_FAST_SLA=0` for full registry floors (bail medium 8500). Deploy `2026-09-09T1437Z-aws-ssm-f28b3550`.

**Token registry:** `nv-draft-length-registry.ts` — 20 types; send `parameters.documentType` + `options.draftLength: low|medium|comprehensive`.

**Probes:** EC2 SSM authoritative (`npm run demo:probe:ec2`, `nv-partner-memory-probe-ec2.sh`). Local without `.local/secrets/runtime.env` → **SKIP** (`key_len=0`), not PASS. Operator JWT for EDJ/Console via `nv-uat-fetch-admin-jwt-ec2.sh`.

#### J.0.3 NSP Prompt Playbook (counsel-grade — 2026-09-15)

Cross-ref: `NYV-INDIAN-LEGAL-PROMPT-ENGINEERING-2026-09-12.md` §H (full doc in NYV repo `documents/working/`).

| User intent | taskType | documentType | draftLength | RAG | Agent |
|-------------|----------|--------------|-------------|-----|-------|
| Quick bail ideas | `legal-draft-fast` | `bail_application` | medium | if docs | A-004 |
| File bail tomorrow | `legal-draft` | `bail_application` | comprehensive | yes | A-004 / Queen |
| Quash S.528 | `legal-draft` | `criminal_petition` | comprehensive | yes | A-004 |
| Writ 226 | `legal-draft` | `writ_petition` | comprehensive | yes | A-004 |
| Legal notice | `legal-draft-fast` | `legal_notice` | medium | optional | A-005 |
| Complex SPA | `legal-draft` | `complex_agreement` | comprehensive | yes | A-001 |
| Research memo | `caselaw-research` | `legal_research` | medium | yes | A-048 |
| Statute map IPC→BNS | `statute-research` | `legal_research` | low | yes | A-047 |
| Chat Q&A | `legal-chat` | `legal_chat` | medium | if matter | A-047 |

**Always send:** `parameters.documentType`, `parameters.cnrFacts` (when case linked), `options.draftLength`, matter `sessionId`.

**Counsel upgrade (NYV gateway):** `options.draftLength: "comprehensive"` OR `options.qualityMode: "counsel"` on `-fast` upgrades to bare `legal-draft` (Queen/Opus). Medium stays on Haiku `-fast` (4096 SLA cap).

**Response contract:** `draftQuality.structureMarkers` — `{ prayer, verification, causeTitle, numberedParas, limitationChecked }`; `draftQuality.authoritiesDelivered`; `attestationRequired` when `reviewRecommended`.
