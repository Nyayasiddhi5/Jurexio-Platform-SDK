# NSP ↔ NYV Integration Handoff Bundle

**Bundle date:** 2026-09-16  
**Prepared for:** NSP integration team  
**Live API:** `https://api.nyayasiddhi.online` (nysdev)  
**Current deploy:** `2026-09-16T0235Z-aws-ssm-1c0adb7d` (commit `1c0adb7d3`, P1 counsel-grade wiring)

> **No secrets in this bundle.** SDK keys, JWTs, and DB URLs live on nysdev canonical env only. Use your existing NSP key provisioning — do not request key values in chat or email.

---

## What to read first

1. **`01-NSP-MIGRATION-GO-2026-09-08.md`** — REQUIRED API contract changes, curl/TypeScript examples, migration checklist, §J post-deploy audit.
2. **`03-PROMPT-PLAYBOOK-J0.3-EXTRACT.md`** — Quick reference: migration checklist, stream/SLA knobs, intent → `taskType` / `documentType` playbook table.
| `04-NSP-OPERATING-PROFILE-2026-09-16.md` | NSP operating profile + §J.0.3 playbook table |
3. **`02-PARTNER-AI-INTEGRATION-FULL-2026-09-02.md`** — Full partner integration reference (§J decision matrix, all task types §J.1–§J.9, prompt pipeline, agent registry).

---

## Bundle contents

| File | Purpose |
|------|---------|
| `00-README-NSP-HANDOFF.md` | This index |
| `01-NSP-MIGRATION-GO-2026-09-08.md` | Migration GO doc — sync/stream payloads, memory `userId`, probe contract |
| `02-PARTNER-AI-INTEGRATION-FULL-2026-09-02.md` | Complete partner AI integration + prompt engineering reference |
| `03-PROMPT-PLAYBOOK-J0.3-EXTRACT.md` | Standalone §J.0.1–§J.0.3 extract (playbook table + always-send fields) |
| `04-NSP-OPERATING-PROFILE-2026-09-16.md` | NSP operating profile + §J.0.3 playbook table |

---

## Frozen API contract summary (2026-09-15)

| Before (deprecated for sync UI) | After (REQUIRED) |
|---|---|
| `taskType: "legal-draft"` from browser/BFF sync | `taskType: "legal-draft-fast"` |
| No `parameters.documentType` | `parameters.documentType` per registry (snake_case) |
| No length hint | `options.draftLength: "medium"` (or `low` / `comprehensive`) |
| No per-user memory id | `X-NYV-User-Id: <numeric>` **or** body `userId: <numeric>` |
| Sync-only progressive UX | `POST /api/nv/orchestrate/stream` for editor/chat streaming |

Bare `legal-draft` remains **counsel-grade async only** (Queen, ~70–94s Opus). Never call from 55–60s UI threads.

**Stream rule:** gated SSE deltas (`gated: true`) → **replace** entire editor body, not append.

**Missing `documentType`:** NYV returns **400** on typed draft paths (enforced post deploy `2026-09-16T0235Z`).

---

## documentType registry (20 types)

**NYV code SSoT:** `nyayavigya-platform-312/src/config/nv-draft-length-registry.ts`  
**Structure checklists:** `nyayavigya-platform-312/src/config/nv-indian-draft-structure-registry.ts` (`INDIAN_DRAFT_STRUCTURE_CHECKLIST`)

**NSP mirror (keep in sync):** `packages/nsp-config/src/drafting/nv-draft-length-registry.ts`

Example keys: `bail_application`, `criminal_petition`, `writ_petition`, `written_statement`, `legal_notice`, `complex_agreement`, `affidavit_simple`, `legal_research`, `legal_chat`, … (20 total — see registry file).

Always send **`parameters.documentType`** + **`options.draftLength`** on every draft request.

---

## Verification (no keys in bundle)

| Probe | Command (NYV repo) |
|---|---|
| Full partner matrix | `npm run demo:probe:ec2` |
| Draft length / SLA | `npm run demo:probe:draft-length:ec2` |
| Memory userId | `bash scripts/nv-partner-memory-probe-ec2.sh` |
| NSP smoke row | `npm run partner:smoke:ec2` |

Probes **SKIP** (not PASS) when keys absent locally — EC2 SSM is authoritative.

---

## Contact / cross-refs (NYV repo paths)

- `documents/working/NYV-INDIAN-LEGAL-PROMPT-ENGINEERING-2026-09-12.md` — prompt pipeline + all 20 documentTypes
- `documents/working/NSP-DRAFT-STREAM-AUDIT-2026-09-09.md` — NSP client stream follow-ups
- `documents/working/NSP-NYM-AI-TASK-ENDPOINTS-2026-08-17.md` — full endpoint matrix

---

## Partner sign-off

**NSP confirmed 2026-09-16** — Playbook alignment via `buildNyvDraftOrchestratePayload` / `draftWire` complete and frozen. No further NSP SDK changes required for counsel-grade P0/P1/P2 (server-side additive only). NYV fixture `nv-counsel-grade-set.v1.json` is CI-only; NSP action: none.
